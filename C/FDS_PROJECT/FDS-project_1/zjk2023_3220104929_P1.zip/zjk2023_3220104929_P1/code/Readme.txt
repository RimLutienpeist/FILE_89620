About how to run:
1.just open the project-1.c file, compile and run it.

2.Then choose the algorithm you want.

3.Then input the exponent you want.

4.Then the result will be output.

About X & K: 
If you need to change X or K when you test, please change it in the header of the source code, where you will see the code such as "#define K1 xxx" and "#define X xxx", only change here to change K or X.

K1 is related to the algorithm 1, 
K2 is related to the algorithm 2(recursion); 
K3 is related to the algorithm 2(iteration). 
